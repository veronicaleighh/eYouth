package com.example.eyouth;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BirthControlPM extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_birth_control_pm);
    }
}